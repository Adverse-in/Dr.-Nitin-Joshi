/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MotionConfig } from 'motion/react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { IntroSection } from './components/IntroSection';
import { WhyAvoidSection } from './components/WhyAvoidSection';
import { TreatmentsSection } from './components/TreatmentsSection';
import { ComfortableCareSection } from './components/ComfortableCareSection';
import { RoadmapSection } from './components/RoadmapSection';
import { TeamSection } from './components/TeamSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FaqSection } from './components/FaqSection';
import { CtaBannerSection } from './components/CtaBannerSection';
import { ContactSection } from './components/ContactSection';
import { FooterSection } from './components/FooterSection';
import { MobileFloatingActions } from './components/MobileFloatingActions';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#F7FAFC] text-[#5B6475]">
        <Header />
        <main>
          <HeroSection />
          <IntroSection />
          <WhyAvoidSection />
          <TreatmentsSection />
          <ComfortableCareSection />
          <RoadmapSection />
          <TeamSection />
          <TestimonialsSection />
          <FaqSection />
          <CtaBannerSection />
          <ContactSection />
        </main>
        <FooterSection />
        <MobileFloatingActions />
      </div>
    </MotionConfig>
  );
}
