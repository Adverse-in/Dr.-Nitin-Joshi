import React from 'react';
import { ArrowRight } from 'lucide-react';

export const ToothMarkIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg
    viewBox="0 0 32 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <path
      d="M10.4 4.5C7.1 4.5 5 7.2 5 10.7C5 13.7 6.3 16.2 7.2 19.2C8.1 22.3 8.8 27.5 11.4 27.5C13.1 27.5 13.8 23.8 14.7 21.4C15.1 20.3 15.5 19.7 16 19.7C16.5 19.7 16.9 20.3 17.3 21.4C18.2 23.8 18.9 27.5 20.6 27.5C23.2 27.5 23.9 22.3 24.8 19.2C25.7 16.2 27 13.7 27 10.7C27 7.2 24.9 4.5 21.6 4.5C19.5 4.5 17.8 5.6 16 5.6C14.2 5.6 12.5 4.5 10.4 4.5Z"
      stroke="currentColor"
      strokeWidth="2.1"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M9.5 9.2C10.1 8.1 11.2 7.5 12.4 7.5"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);

interface PillTagProps {
  children: React.ReactNode;
  variant?: 'light' | 'dark' | 'teal';
  className?: string;
}

export const PillTag: React.FC<PillTagProps> = ({
  children,
  variant = 'light',
  className = '',
}) => {
  const styles =
    variant === 'dark'
      ? 'border border-white/30 text-white/95 bg-white/10'
      : variant === 'teal'
      ? 'border border-[#3E8A9C]/35 text-[#0B4A5A] bg-[#4FB3C8]/10'
      : 'border border-[#14173A]/15 text-[#0B4A5A] bg-white/80';

  return <span className={`pill-label ${styles} ${className}`}>{children}</span>;
};

interface CtaButtonProps {
  children: React.ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: 'primary' | 'white' | 'outline';
  external?: boolean;
  className?: string;
  type?: 'button' | 'submit';
}

export const CtaButton: React.FC<CtaButtonProps> = ({
  children,
  href,
  onClick,
  variant = 'primary',
  external = false,
  className = '',
  type = 'button',
}) => {
  const base =
    'group inline-flex items-center justify-center gap-2.5 rounded-full px-6 py-3.5 text-[15px] font-medium whitespace-nowrap shrink-0 transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8] focus-visible:ring-offset-2';

  const variantClass =
    variant === 'white'
      ? 'bg-white text-[#0B4A5A] hover:bg-[#F7FAFC] shadow-sm'
      : variant === 'outline'
      ? 'border border-[#0B4A5A]/20 bg-white text-[#0B4A5A] hover:border-[#0B4A5A]/40 hover:bg-[#F7FAFC]'
      : 'bg-[#0B4A5A] text-white hover:bg-[#093c49] shadow-[0_8px_20px_-6px_rgba(11,74,90,0.4)]';

  const content = (
    <>
      <span>{children}</span>
      <ArrowRight
        className="w-4 h-4 transition-transform duration-200 ease-out group-hover:translate-x-1"
        aria-hidden="true"
      />
    </>
  );

  if (href) {
    return (
      <a
        href={href}
        target={external ? '_blank' : undefined}
        rel={external ? 'noopener noreferrer' : undefined}
        className={`${base} ${variantClass} ${className}`}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      type={type}
      onClick={onClick}
      className={`${base} ${variantClass} ${className}`}
    >
      {content}
    </button>
  );
};
