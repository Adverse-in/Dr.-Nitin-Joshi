import React from 'react';
import { motion } from 'motion/react';
import { CLINIC_IMAGES } from '../data/clinicData';
import { CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { PillTag, ToothMarkIcon } from './ClinicUI';

export const ComfortableCareSection: React.FC = () => {
  return (
    <section id="benefits" className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <RevealBlock className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 md:mb-12">
          <div>
            <PillTag variant="teal" className="mb-4">
              Patient comfort first
            </PillTag>
            <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-[#14173A]">
              Comfortable dental care
            </h2>
          </div>
          <p className="text-[16px] text-[#5B6475] max-w-[420px]">
            Thoughtful scheduling, gentle techniques, and seasoned specialists designed around calm
            visits.
          </p>
        </RevealBlock>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Card A: Dark Teal Same Day Solutions */}
          <motion.article
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0, ease: CLINIC_EASE }}
            className="rounded-[20px] md:rounded-[24px] bg-[#0B4A5A] text-white p-7 md:p-8 min-h-[430px] flex flex-col justify-between shadow-[0_18px_40px_-14px_rgba(11,74,90,0.35)] hover:-translate-y-1.5 transition-transform duration-300"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-[12px] uppercase tracking-[0.08em] font-semibold text-[#4FB3C8]">
                  Prompt relief
                </p>
                <h3 className="mt-2 text-[26px] font-semibold leading-[1.2] text-white">
                  Same day solutions
                </h3>
              </div>
              <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/10 text-white shrink-0">
                <ToothMarkIcon className="w-5 h-5" />
              </span>
            </div>

            <p className="text-[16px] leading-[1.65] text-white/85 my-6">
              Toothache, broken fillings, or emergency care—with 4 dedicated dental chairs and
              in-house digital X-rays, most patients are examined and relieved the very same day.
            </p>

            <div className="pt-5 border-t border-white/15 flex items-center gap-3.5">
              <div className="flex -space-x-2.5 shrink-0" aria-hidden="true">
                <img
                  src={CLINIC_IMAGES.cosmeticSmile}
                  alt=""
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover object-top ring-2 ring-[#0B4A5A]"
                />
                <img
                  src={CLINIC_IMAGES.ctaPatient}
                  alt=""
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover object-top ring-2 ring-[#0B4A5A]"
                />
                <img
                  src={CLINIC_IMAGES.worriedPatient}
                  alt=""
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover object-top ring-2 ring-[#0B4A5A]"
                />
              </div>
              <p className="text-[13px] leading-[1.45] text-white/85">
                Walk-in emergency care &amp; swift appointments from 10 AM.
              </p>
            </div>
          </motion.article>

          {/* Card B: Photo Card Gentle, Smart Care */}
          <motion.article
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.12, ease: CLINIC_EASE }}
            className="relative overflow-hidden rounded-[20px] md:rounded-[24px] min-h-[430px] border border-[#14173A]/[0.06] group hover:-translate-y-1.5 transition-transform duration-300"
          >
            <img
              src={CLINIC_IMAGES.preventiveCheckup}
              alt="Friendly dentist gently checking a smiling patient in a bright treatment room"
              loading="lazy"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
            />
            <div
              className="absolute inset-0 bg-gradient-to-b from-[#14173A]/75 via-[#14173A]/20 to-transparent"
              aria-hidden="true"
            />
            <div className="relative z-10 p-7 md:p-8 text-white">
              <p className="text-[12px] uppercase tracking-[0.08em] font-semibold text-[#4FB3C8]">
                Calm communication
              </p>
              <h3 className="mt-2 text-[26px] font-semibold leading-[1.2] text-white">
                Gentle, smart care
              </h3>
              <p className="mt-2.5 text-[15px] leading-[1.55] text-white/90 max-w-[280px]">
                Every procedure is explained clearly beforehand with laser precision and zero rush.
              </p>
            </div>
          </motion.article>

          {/* Card C: Teal Card Certified Dentists */}
          <motion.article
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.24, ease: CLINIC_EASE }}
            className="relative overflow-hidden rounded-[20px] md:rounded-[24px] bg-[#3E8A9C] min-h-[430px] flex flex-col justify-between group hover:-translate-y-1.5 transition-transform duration-300"
          >
            <img
              src={CLINIC_IMAGES.drNitinJoshi}
              alt="Dr. Nitin Joshi, implant and cosmetic dentist in Dombivli West"
              loading="lazy"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]"
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-[#0B4A5A]/75 via-transparent to-[#0B4A5A]/25"
              aria-hidden="true"
            />

            <div className="relative z-10 p-7 md:p-8">
              <PillTag variant="dark">Certified dentists</PillTag>
            </div>

            <div className="relative z-10 p-4 md:p-5">
              <div className="glass-surface-dark rounded-[18px] p-5">
                <h3 className="text-[19px] font-semibold text-[#14173A]">Dr. Nitin Joshi</h3>
                <p className="text-[13px] font-medium text-[#0B4A5A] mt-0.5">
                  Implant &amp; cosmetic dentist
                </p>
                <p className="text-[13px] text-[#5B6475] mt-2">
                  40 years of family dental care in Dombivli
                </p>
              </div>
            </div>
          </motion.article>
        </div>
      </div>
    </section>
  );
};
