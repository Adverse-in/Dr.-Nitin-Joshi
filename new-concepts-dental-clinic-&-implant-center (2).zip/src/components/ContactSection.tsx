import React, { useState } from 'react';
import { CheckCircle2, Clock, MapPin, MessageCircle, Phone } from 'lucide-react';
import { ALL_SERVICES, CLINIC_INFO } from '../data/clinicData';
import { RevealBlock } from './MotionPrimitives';
import { CtaButton, PillTag } from './ClinicUI';

interface FormState {
  fullName: string;
  phone: string;
  preferredDate: string;
  service: string;
  message: string;
}

interface FormErrors {
  fullName?: string;
  phone?: string;
  preferredDate?: string;
  service?: string;
}

export const ContactSection: React.FC = () => {
  const [form, setForm] = useState<FormState>({
    fullName: '',
    phone: '',
    preferredDate: '',
    service: '',
    message: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const validate = (): FormErrors => {
    const next: FormErrors = {};
    if (form.fullName.trim().length < 2) {
      next.fullName = 'Please enter your full name.';
    }
    const digitsOnly = form.phone.replace(/\D/g, '');
    if (digitsOnly.length < 10 || digitsOnly.length > 13) {
      next.phone = 'Please enter a valid 10-digit phone number.';
    }
    if (!form.preferredDate) {
      next.preferredDate = 'Please select a preferred date.';
    }
    if (!form.service) {
      next.service = 'Please choose a dental service.';
    }
    return next;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length === 0) {
      setSubmitted(true);
    }
  };

  const handleReset = () => {
    setForm({
      fullName: '',
      phone: '',
      preferredDate: '',
      service: '',
      message: '',
    });
    setErrors({});
    setSubmitted(false);
  };

  const todayIso = new Date().toISOString().split('T')[0];

  return (
    <section
      id="contact"
      className="relative overflow-hidden bg-[#0B4A5A] text-white py-[72px] md:py-[120px]"
    >
      {/* Soft Radial Aqua Glows */}
      <div
        className="pointer-events-none absolute -top-40 -left-32 w-[520px] h-[520px] rounded-full bg-[#4FB3C8]/20 blur-[110px]"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-44 -right-28 w-[500px] h-[500px] rounded-full bg-[#3E8A9C]/35 blur-[120px]"
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-[1200px] mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left Column: Address, Phone, WhatsApp, Hours, Embedded Map */}
          <RevealBlock className="lg:col-span-6 space-y-7">
            <div>
              <PillTag variant="dark" className="mb-4">
                Visit our clinic
              </PillTag>
              <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-white">
                {CLINIC_INFO.fullName}
              </h2>
              <p className="mt-3 text-[16px] leading-[1.6] text-white/80">
                {CLINIC_INFO.tagline}
              </p>
            </div>

            <div className="space-y-4 text-[15px]">
              <div className="flex items-start gap-3.5">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/10 text-[#4FB3C8] shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="text-[12px] uppercase tracking-[0.06em] font-semibold text-[#4FB3C8]">
                    Clinic address
                  </p>
                  <p className="mt-1 leading-[1.6] text-white/90">{CLINIC_INFO.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/10 text-[#4FB3C8] shrink-0 mt-0.5">
                  <Phone className="w-4 h-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="text-[12px] uppercase tracking-[0.06em] font-semibold text-[#4FB3C8]">
                    Phone
                  </p>
                  <a
                    href={CLINIC_INFO.phoneHref}
                    className="mt-1 inline-block text-[17px] font-semibold text-white hover:text-[#4FB3C8] transition-colors tabular-nums"
                  >
                    {CLINIC_INFO.phoneDisplay}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/10 text-[#4FB3C8] shrink-0 mt-0.5">
                  <Clock className="w-4 h-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="text-[12px] uppercase tracking-[0.06em] font-semibold text-[#4FB3C8]">
                    Clinic hours
                  </p>
                  <p className="mt-1 text-white/90">{CLINIC_INFO.hours}</p>
                </div>
              </div>
            </div>

            {/* Direct Action Buttons */}
            <div className="flex flex-wrap gap-3 pt-1">
              <a
                href={CLINIC_INFO.phoneHref}
                className="inline-flex items-center gap-2 rounded-full bg-white text-[#0B4A5A] px-5 py-3 text-[14px] font-medium hover:bg-[#F7FAFC] transition-colors"
              >
                <Phone className="w-4 h-4" aria-hidden="true" />
                <span>Tap to call</span>
              </a>

              {/* [PLACEHOLDER: confirm official WhatsApp number for clinic] */}
              <a
                href={CLINIC_INFO.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 text-white px-5 py-3 text-[14px] font-medium hover:bg-white/20 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-[#4FB3C8]" aria-hidden="true" />
                <span>WhatsApp [PLACEHOLDER number]</span>
              </a>
            </div>

            {/* Embedded Google Map of the Clinic */}
            <div className="overflow-hidden rounded-[20px] md:rounded-[24px] border border-white/15 bg-[#083946] h-[230px]">
              <iframe
                title="Map showing Nitin Joshi's New Concepts Dental Clinic in Dombivli West"
                src={CLINIC_INFO.googleMapsEmbedUrl}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full border-0"
              />
            </div>
          </RevealBlock>

          {/* Right Column: White Appointment & Enquiry Form Card */}
          <RevealBlock delay={0.12} className="lg:col-span-6">
            <div className="rounded-[20px] md:rounded-[24px] bg-white text-[#14173A] p-6 sm:p-8 md:p-10 shadow-[0_24px_60px_-16px_rgba(0,0,0,0.28)]">
              {submitted ? (
                <div
                  role="status"
                  aria-live="polite"
                  className="py-10 text-center space-y-4"
                >
                  <span className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#4FB3C8]/20 text-[#0B4A5A] mx-auto">
                    <CheckCircle2 className="w-7 h-7" aria-hidden="true" />
                  </span>
                  <h3 className="text-[24px] font-semibold text-[#14173A]">
                    Request received!
                  </h3>
                  <p className="text-[15px] leading-[1.6] text-[#5B6475] max-w-[380px] mx-auto">
                    Thank you, <span className="font-semibold text-[#14173A]">{form.fullName}</span>
                    . Our clinic desk will confirm your <span className="font-medium">{form.service}</span>{' '}
                    visit on <span className="font-medium">{form.preferredDate}</span> via{' '}
                    <span className="tabular-nums">{form.phone}</span>.
                  </p>
                  <div className="pt-3 flex flex-wrap justify-center gap-3">
                    <CtaButton href={CLINIC_INFO.bookingUrl} external variant="primary">
                      Confirm on clinicia.com
                    </CtaButton>
                    <button
                      type="button"
                      onClick={handleReset}
                      className="rounded-full px-5 py-3 text-[14px] font-medium text-[#0B4A5A] hover:bg-[#F7FAFC] transition-colors"
                    >
                      Send another enquiry
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <h3 className="text-[26px] md:text-[30px] font-semibold leading-[1.2] tracking-[-0.02em] text-[#14173A]">
                    We&apos;d love to hear from you!
                  </h3>
                  <p className="mt-2 text-[15px] text-[#5B6475]">
                    Request an appointment or ask about dental implant EMI options.
                  </p>

                  <form onSubmit={handleSubmit} noValidate className="mt-7 space-y-5">
                    <div>
                      <label
                        htmlFor="contact-fullName"
                        className="block text-[13px] font-medium text-[#14173A] mb-1.5"
                      >
                        Full name
                      </label>
                      <input
                        id="contact-fullName"
                        type="text"
                        value={form.fullName}
                        onChange={(e) => {
                          setForm({ ...form, fullName: e.target.value });
                          if (errors.fullName) setErrors({ ...errors, fullName: undefined });
                        }}
                        placeholder="e.g. Rajesh Kulkarni"
                        className={`w-full rounded-[14px] border px-4 py-3 text-[15px] text-[#14173A] bg-[#F7FAFC] placeholder:text-[#5B6475]/60 focus:outline-none focus:ring-2 focus:ring-[#4FB3C8] ${
                          errors.fullName ? 'border-red-500' : 'border-[#14173A]/12'
                        }`}
                      />
                      {errors.fullName && (
                        <p className="mt-1.5 text-[12px] font-medium text-red-600">
                          {errors.fullName}
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="contact-phone"
                          className="block text-[13px] font-medium text-[#14173A] mb-1.5"
                        >
                          Phone number
                        </label>
                        <input
                          id="contact-phone"
                          type="tel"
                          value={form.phone}
                          onChange={(e) => {
                            setForm({ ...form, phone: e.target.value });
                            if (errors.phone) setErrors({ ...errors, phone: undefined });
                          }}
                          placeholder="e.g. 099676 68923"
                          className={`w-full rounded-[14px] border px-4 py-3 text-[15px] text-[#14173A] bg-[#F7FAFC] placeholder:text-[#5B6475]/60 focus:outline-none focus:ring-2 focus:ring-[#4FB3C8] ${
                            errors.phone ? 'border-red-500' : 'border-[#14173A]/12'
                          }`}
                        />
                        {errors.phone && (
                          <p className="mt-1.5 text-[12px] font-medium text-red-600">
                            {errors.phone}
                          </p>
                        )}
                      </div>

                      <div>
                        <label
                          htmlFor="contact-date"
                          className="block text-[13px] font-medium text-[#14173A] mb-1.5"
                        >
                          Preferred date
                        </label>
                        <input
                          id="contact-date"
                          type="date"
                          min={todayIso}
                          value={form.preferredDate}
                          onChange={(e) => {
                            setForm({ ...form, preferredDate: e.target.value });
                            if (errors.preferredDate)
                              setErrors({ ...errors, preferredDate: undefined });
                          }}
                          className={`w-full rounded-[14px] border px-4 py-3 text-[15px] text-[#14173A] bg-[#F7FAFC] focus:outline-none focus:ring-2 focus:ring-[#4FB3C8] ${
                            errors.preferredDate ? 'border-red-500' : 'border-[#14173A]/12'
                          }`}
                        />
                        {errors.preferredDate && (
                          <p className="mt-1.5 text-[12px] font-medium text-red-600">
                            {errors.preferredDate}
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-service"
                        className="block text-[13px] font-medium text-[#14173A] mb-1.5"
                      >
                        Service
                      </label>
                      <select
                        id="contact-service"
                        value={form.service}
                        onChange={(e) => {
                          setForm({ ...form, service: e.target.value });
                          if (errors.service) setErrors({ ...errors, service: undefined });
                        }}
                        className={`w-full rounded-[14px] border px-4 py-3 text-[15px] text-[#14173A] bg-[#F7FAFC] focus:outline-none focus:ring-2 focus:ring-[#4FB3C8] ${
                          errors.service ? 'border-red-500' : 'border-[#14173A]/12'
                        }`}
                      >
                        <option value="">Select a dental service</option>
                        {ALL_SERVICES.map((service) => (
                          <option key={service} value={service}>
                            {service}
                          </option>
                        ))}
                      </select>
                      {errors.service && (
                        <p className="mt-1.5 text-[12px] font-medium text-red-600">
                          {errors.service}
                        </p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-message"
                        className="block text-[13px] font-medium text-[#14173A] mb-1.5"
                      >
                        Message (optional)
                      </label>
                      <textarea
                        id="contact-message"
                        rows={3}
                        value={form.message}
                        onChange={(e) => setForm({ ...form, message: e.target.value })}
                        placeholder="Tell us about your symptoms, preferred time after 10 AM, or implant EMI questions..."
                        className="w-full rounded-[14px] border border-[#14173A]/12 px-4 py-3 text-[15px] text-[#14173A] bg-[#F7FAFC] placeholder:text-[#5B6475]/60 focus:outline-none focus:ring-2 focus:ring-[#4FB3C8]"
                      />
                    </div>

                    <CtaButton type="submit" variant="primary" className="w-full">
                      Send appointment request
                    </CtaButton>
                  </form>
                </>
              )}
            </div>
          </RevealBlock>
        </div>
      </div>
    </section>
  );
};
