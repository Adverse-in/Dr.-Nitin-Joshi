import React from 'react';
import { motion } from 'motion/react';
import { CLINIC_IMAGES, CLINIC_INFO } from '../data/clinicData';
import { CLINIC_EASE } from './MotionPrimitives';
import { CtaButton } from './ClinicUI';

export const CtaBannerSection: React.FC = () => {
  return (
    <section className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <div className="relative overflow-hidden rounded-[20px] md:rounded-[24px] min-h-[360px] md:min-h-[420px] flex items-center shadow-[0_24px_60px_-20px_rgba(11,74,90,0.3)]">
          {/* Slow zoom-out on enter */}
          <motion.img
            initial={{ scale: 1.07 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.95, ease: CLINIC_EASE }}
            src={CLINIC_IMAGES.ctaPatient}
            alt="Smiling patient in a bright sunlit dental clinic lounge"
            loading="lazy"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover object-center"
          />

          {/* Left-to-right Teal Gradient Overlay */}
          <div
            className="absolute inset-0 bg-gradient-to-r from-[#0B4A5A]/95 via-[#0B4A5A]/80 to-[#0B4A5A]/25"
            aria-hidden="true"
          />

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.7, ease: CLINIC_EASE }}
            className="relative z-10 p-7 sm:p-12 md:p-16 max-w-[600px] text-white space-y-5"
          >
            <h2 className="text-[32px] sm:text-[38px] md:text-[44px] font-semibold leading-[1.12] tracking-[-0.02em] text-white">
              A healthier smile starts here.
            </h2>
            <p className="text-[16px] leading-[1.6] text-white/85">
              Book your consultation in Dombivli West for gentle check-ups, laser care, or dental
              implants with EMI.
            </p>
            <div className="pt-2">
              {/* [PLACEHOLDER: exact clinicia.com clinic appointment booking URL] */}
              <CtaButton href={CLINIC_INFO.bookingUrl} external variant="white">
                Make an appointment
              </CtaButton>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
