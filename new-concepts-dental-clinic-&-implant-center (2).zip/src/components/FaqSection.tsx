import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Plus } from 'lucide-react';
import { FAQ_ITEMS } from '../data/clinicData';
import { CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { PillTag } from './ClinicUI';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleItem = (idx: number) => {
    setOpenIndex((current) => (current === idx ? null : idx));
  };

  return (
    <section id="faq" className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left Sticky Header */}
          <RevealBlock className="lg:col-span-5 lg:sticky lg:top-24">
            <PillTag variant="teal" className="mb-4">
              FAQs
            </PillTag>
            <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-[#14173A]">
              Frequently asked questions
            </h2>
            <p className="mt-4 text-[16px] leading-[1.6] text-[#5B6475]">
              Clear, honest answers about appointments, pain-free implants, EMI options, and
              everyday family care in Dombivli West.
            </p>
          </RevealBlock>

          {/* Right Accordion List */}
          <RevealBlock delay={0.1} className="lg:col-span-7">
            <div className="border-t border-[#14173A]/[0.08]">
              {FAQ_ITEMS.map((item, idx) => {
                const isOpen = openIndex === idx;
                const contentId = `faq-panel-${idx}`;
                const triggerId = `faq-trigger-${idx}`;

                return (
                  <div key={item.question} className="border-b border-[#14173A]/[0.08]">
                    <h3>
                      <button
                        type="button"
                        id={triggerId}
                        aria-expanded={isOpen}
                        aria-controls={contentId}
                        onClick={() => toggleItem(idx)}
                        className="w-full py-6 flex items-center justify-between gap-6 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8] rounded-md"
                      >
                        <span
                          className={`text-[18px] md:text-[20px] font-medium leading-[1.35] transition-colors duration-200 ${
                            isOpen ? 'text-[#3E8A9C]' : 'text-[#14173A]'
                          }`}
                        >
                          {item.question}
                        </span>
                        <span
                          className={`inline-flex items-center justify-center w-9 h-9 rounded-full border shrink-0 transition-all duration-300 ${
                            isOpen
                              ? 'border-[#3E8A9C] bg-[#3E8A9C]/10 text-[#3E8A9C] rotate-45'
                              : 'border-[#14173A]/15 text-[#14173A]'
                          }`}
                          aria-hidden="true"
                        >
                          <Plus className="w-4 h-4" />
                        </span>
                      </button>
                    </h3>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          id={contentId}
                          role="region"
                          aria-labelledby={triggerId}
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.35, ease: CLINIC_EASE }}
                          className="overflow-hidden"
                        >
                          <p className="pb-6 pr-10 text-[15px] md:text-[16px] leading-[1.65] text-[#5B6475]">
                            {item.answer}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </RevealBlock>
        </div>
      </div>
    </section>
  );
};
