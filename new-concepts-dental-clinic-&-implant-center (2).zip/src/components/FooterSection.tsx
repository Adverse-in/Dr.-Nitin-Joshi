import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Facebook, Instagram, Linkedin } from 'lucide-react';
import { CLINIC_IMAGES, CLINIC_INFO } from '../data/clinicData';

const FOOTER_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Treatments', href: '#treatments' },
  { label: 'Benefits', href: '#benefits' },
  { label: 'Team', href: '#team' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'Contact', href: '#contact' },
];

export const FooterSection: React.FC = () => {
  const wordmarkRef = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: wordmarkRef,
    offset: ['start end', 'end end'],
  });
  // Brightens from semi-transparent white to full white as it scrolls into view
  const wordmarkOpacity = useTransform(scrollYProgress, [0, 0.85], [0.22, 1]);

  return (
    <footer className="bg-[#0B4A5A] text-white border-t border-white/10 pt-14 md:pt-20 pb-10 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center pb-14">
          {/* Left: Glossy 3D Tooth Illustration */}
          <div className="md:col-span-4 flex justify-center md:justify-start">
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full overflow-hidden animate-gentle-float">
              <img
                src={CLINIC_IMAGES.footerTooth}
                alt="Sculptural porcelain tooth illustration"
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover mix-blend-lighten opacity-95"
              />
            </div>
          </div>

          {/* Center: Link Column */}
          <div className="md:col-span-3">
            <p className="text-[11px] uppercase tracking-[0.08em] font-semibold text-[#4FB3C8] mb-4">
              Explore
            </p>
            <ul className="space-y-3 text-[15px]">
              {FOOTER_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-white/80 hover:text-white transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Right: Contact & Social Icons */}
          <div className="md:col-span-5 space-y-4">
            <p className="text-[11px] uppercase tracking-[0.08em] font-semibold text-[#4FB3C8]">
              Contact &amp; Clinic
            </p>
            <p className="text-[15px] leading-[1.6] text-white/85">{CLINIC_INFO.address}</p>
            <div className="space-y-1.5 text-[15px]">
              <p>
                <a
                  href={CLINIC_INFO.phoneHref}
                  className="font-medium text-white hover:text-[#4FB3C8] transition-colors tabular-nums"
                >
                  {CLINIC_INFO.phoneDisplay}
                </a>
              </p>
              <p className="text-white/75">{CLINIC_INFO.emailDisplay}</p>
            </div>

            {/* Social Links — [PLACEHOLDER: replace # with official clinic social URLs] */}
            <div className="pt-2 flex items-center gap-3">
              <a
                href="#contact"
                aria-label="Instagram [PLACEHOLDER]"
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/80 hover:text-white hover:border-white/50 transition-colors"
              >
                <Instagram className="w-4 h-4" aria-hidden="true" />
              </a>
              <a
                href="#contact"
                aria-label="Facebook [PLACEHOLDER]"
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/80 hover:text-white hover:border-white/50 transition-colors"
              >
                <Facebook className="w-4 h-4" aria-hidden="true" />
              </a>
              <a
                href="#contact"
                aria-label="LinkedIn [PLACEHOLDER]"
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white/80 hover:text-white hover:border-white/50 transition-colors"
              >
                <Linkedin className="w-4 h-4" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>

        {/* Full-Width Wordmark that Brightens on Scroll */}
        <div ref={wordmarkRef} className="pt-4 border-t border-white/10">
          <motion.p
            style={{ opacity: wordmarkOpacity }}
            className="text-[clamp(2.75rem,11.2vw,8.6rem)] font-semibold leading-[0.95] tracking-[-0.03em] text-white select-none whitespace-nowrap"
          >
            New Concepts.
          </motion.p>

          <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[13px] text-white/65">
            <p>© {new Date().getFullYear()} {CLINIC_INFO.fullName}. All rights reserved.</p>
            <p>Dombivli West · Serving families for 40 years</p>
          </div>
        </div>
      </div>
    </footer>
  );
};
