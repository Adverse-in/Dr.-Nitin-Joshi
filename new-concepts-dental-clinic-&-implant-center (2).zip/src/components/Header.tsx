import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowUpRight, Phone, X } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';
import { CLINIC_EASE } from './MotionPrimitives';
import { ToothMarkIcon } from './ClinicUI';

const MENU_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Treatments', href: '#treatments' },
  { label: 'Benefits', href: '#benefits' },
  { label: 'Team', href: '#team' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [menuOpen]);

  return (
    <>
      <header
        className={`sticky top-0 z-40 transition-all duration-300 bg-white/80 backdrop-blur-md ${
          scrolled
            ? 'border-b border-[#14173A]/[0.08] shadow-[0_4px_20px_-10px_rgba(20,23,58,0.08)]'
            : 'border-b border-transparent'
        }`}
      >
        <div className="max-w-[1200px] mx-auto px-4 md:px-6 h-16 md:h-[74px] flex items-center justify-between gap-8">
          <a
            href="#top"
            className="inline-flex items-center gap-2.5 text-[#14173A] font-semibold text-[16px] md:text-[17px] tracking-tight whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8] rounded-lg py-1"
          >
            <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-[#0B4A5A] text-white">
              <ToothMarkIcon className="w-5 h-5" />
            </span>
            <span>{CLINIC_INFO.brandShort}</span>
          </a>

          <div className="flex items-center gap-6 shrink-0">
            <a
              href={CLINIC_INFO.phoneHref}
              className="hidden md:inline-flex items-center gap-2 text-[14px] font-medium text-[#0B4A5A] hover:text-[#3E8A9C] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8] rounded-full px-3 py-1.5"
            >
              <Phone className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Call now · {CLINIC_INFO.phoneDisplay}</span>
            </a>

            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              aria-label="Open navigation menu"
              aria-expanded={menuOpen}
              className="inline-flex items-center justify-center w-11 h-11 rounded-full border border-[#14173A]/10 bg-white/90 text-[#14173A] hover:border-[#0B4A5A]/30 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
            >
              <span className="flex flex-col gap-[6px] w-5" aria-hidden="true">
                <span className="block h-[1.75px] w-full bg-[#14173A] rounded-full" />
                <span className="block h-[1.75px] w-4 ml-auto bg-[#0B4A5A] rounded-full" />
              </span>
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, ease: CLINIC_EASE }}
            role="dialog"
            aria-modal="true"
            aria-label="Site navigation"
            className="fixed inset-0 z-50 bg-[#0B4A5A] text-white flex flex-col justify-between overflow-y-auto"
          >
            {/* Top Bar Inside Overlay */}
            <div className="max-w-[1200px] w-full mx-auto px-4 md:px-6 h-16 md:h-[74px] flex items-center justify-between shrink-0">
              <div className="inline-flex items-center gap-2.5 font-semibold text-[16px] md:text-[17px] tracking-tight">
                <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-white/15 text-white">
                  <ToothMarkIcon className="w-5 h-5" />
                </span>
                <span>{CLINIC_INFO.brandShort}</span>
              </div>

              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                aria-label="Close navigation menu"
                className="inline-flex items-center justify-center w-11 h-11 rounded-full border border-white/25 bg-white/10 text-white hover:bg-white/20 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            {/* Large Staggered Links */}
            <nav className="max-w-[1200px] w-full mx-auto px-4 md:px-6 py-8 md:py-12 grid grid-cols-1 lg:grid-cols-12 gap-10 items-end">
              <ul className="lg:col-span-8 space-y-2 md:space-y-3">
                {MENU_LINKS.map((link, idx) => (
                  <motion.li
                    key={link.href}
                    initial={{ opacity: 0, x: -24 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -16 }}
                    transition={{
                      duration: 0.45,
                      delay: 0.06 + idx * 0.055,
                      ease: CLINIC_EASE,
                    }}
                  >
                    <a
                      href={link.href}
                      onClick={() => setMenuOpen(false)}
                      className="group inline-flex items-center gap-4 text-[32px] sm:text-[42px] md:text-[52px] font-semibold tracking-tight leading-[1.15] text-white/90 hover:text-white transition-colors"
                    >
                      <span className="text-[13px] font-medium text-[#4FB3C8] tabular-nums w-6">
                        0{idx + 1}
                      </span>
                      <span>{link.label}</span>
                      <ArrowUpRight
                        className="w-6 h-6 opacity-0 -translate-x-2 transition-all duration-200 group-hover:opacity-100 group-hover:translate-x-0 text-[#4FB3C8]"
                        aria-hidden="true"
                      />
                    </a>
                  </motion.li>
                ))}
              </ul>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.35, ease: CLINIC_EASE }}
                className="lg:col-span-4 border-t lg:border-t-0 lg:border-l border-white/15 pt-6 lg:pt-0 lg:pl-8 space-y-4 text-white/80 text-[15px]"
              >
                <p className="text-[11px] uppercase tracking-[0.08em] font-semibold text-[#4FB3C8]">
                  Dombivli West Clinic
                </p>
                <p className="leading-relaxed">{CLINIC_INFO.address}</p>
                <p className="text-white font-medium">{CLINIC_INFO.hours}</p>
                <div className="pt-2 flex flex-wrap gap-3">
                  <a
                    href={CLINIC_INFO.phoneHref}
                    className="inline-flex items-center gap-2 rounded-full bg-white text-[#0B4A5A] px-5 py-2.5 text-[14px] font-medium hover:bg-[#F7FAFC] transition-colors"
                  >
                    <Phone className="w-4 h-4" aria-hidden="true" />
                    <span>{CLINIC_INFO.phoneDisplay}</span>
                  </a>
                </div>
              </motion.div>
            </nav>

            <div className="max-w-[1200px] w-full mx-auto px-4 md:px-6 py-5 border-t border-white/10 text-[13px] text-white/60 flex flex-wrap justify-between gap-2">
              <span>{CLINIC_INFO.fullName}</span>
              <span>4.9★ Google Rating · 552+ Reviews</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
