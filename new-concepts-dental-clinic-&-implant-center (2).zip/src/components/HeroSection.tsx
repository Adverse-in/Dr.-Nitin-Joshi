import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Check } from 'lucide-react';
import { CLINIC_IMAGES, CLINIC_INFO } from '../data/clinicData';
import { CLINIC_EASE, MaskedHeadlineLine } from './MotionPrimitives';
import { CtaButton, PillTag } from './ClinicUI';

export const HeroSection: React.FC = () => {
  const imageWrapperRef = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: imageWrapperRef,
    offset: ['start end', 'end start'],
  });
  // Subtle parallax: moves 40px slower across scroll range
  const parallaxY = useTransform(scrollYProgress, [0, 1], [-20, 20]);

  return (
    <section id="top" className="pt-8 md:pt-14 pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: CLINIC_EASE }}
          className="mb-6"
        >
          <PillTag variant="teal">Trusted in Dombivli for 40 years</PillTag>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end mb-10 md:mb-14">
          <div className="lg:col-span-7">
            <h1 className="text-[40px] sm:text-[50px] lg:text-[62px] font-semibold leading-[1.06] tracking-[-0.02em] text-[#14173A]">
              <MaskedHeadlineLine delay={0.05}>Painless implants.</MaskedHeadlineLine>
              <MaskedHeadlineLine delay={0.17}>Confident smiles.</MaskedHeadlineLine>
              <MaskedHeadlineLine delay={0.29} className="text-[#0B4A5A]">
                Trusted care.
              </MaskedHeadlineLine>
            </h1>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.3, ease: CLINIC_EASE }}
            className="lg:col-span-5 space-y-5"
          >
            <p className="text-[16px] leading-[1.65] text-[#5B6475]">
              A modern 4-chair dental clinic in Dombivli West equipped with gentle laser dentistry,
              low-dose digital X-rays, and flexible EMI for dental implants—one of its kind for
              multi-generational family care.
            </p>

            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[14px] font-medium text-[#14173A]">
              <span className="inline-flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#4FB3C8]/20 text-[#0B4A5A]">
                  <Check className="w-3.5 h-3.5" aria-hidden="true" />
                </span>
                <span>4.9 Google rating</span>
              </span>
              <span className="inline-flex items-center gap-2">
                <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#4FB3C8]/20 text-[#0B4A5A]">
                  <Check className="w-3.5 h-3.5" aria-hidden="true" />
                </span>
                <span>Safe &amp; painless</span>
              </span>
            </div>

            <div className="pt-1 flex flex-wrap items-center gap-4">
              {/* [PLACEHOLDER: verify exact clinicia.com booking URL for clinic] */}
              <CtaButton href={CLINIC_INFO.bookingUrl} external variant="primary">
                Book your appointment
              </CtaButton>
              <a
                href="#contact"
                className="text-[14px] font-medium text-[#3E8A9C] hover:text-[#0B4A5A] transition-colors underline underline-offset-4 decoration-[#3E8A9C]/40"
              >
                Or request a callback
              </a>
            </div>
          </motion.div>
        </div>

        {/* Full-width Hero Media Frame */}
        <div ref={imageWrapperRef} className="relative">
          <motion.div
            initial={{ opacity: 0, scale: 1.08 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, ease: CLINIC_EASE }}
            className="overflow-hidden rounded-[20px] md:rounded-[24px] border border-[#14173A]/[0.06] shadow-[0_24px_60px_-20px_rgba(11,74,90,0.2)] bg-[#E6EFF3] aspect-[16/10] sm:aspect-[16/9]"
          >
            <motion.img
              style={{ y: parallaxY }}
              src={CLINIC_IMAGES.heroTreatment}
              alt="Patient smiling calmly in a bright modern dental clinic chair during consultation at New Concepts Dental Dombivli"
              referrerPolicy="no-referrer"
              className="w-full h-[112%] -mt-[4%] object-cover object-center"
            />
          </motion.div>

          {/* Left Floating Glass Stat Card */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.45, ease: CLINIC_EASE }}
            className="mt-4 md:mt-0 md:absolute md:left-6 md:bottom-6 max-w-[260px]"
          >
            <div className="glass-surface-dark rounded-[20px] md:rounded-[24px] p-5 animate-gentle-float">
              <div className="flex items-baseline gap-2.5">
                <span className="text-[36px] md:text-[42px] font-semibold leading-none text-[#0B4A5A] tabular-nums">
                  3x
                </span>
                <span className="text-[15px] font-semibold text-[#14173A]">
                  Faster recovery
                </span>
              </div>
              <p className="mt-2 text-[13px] leading-[1.5] text-[#5B6475]">
                Precision laser dentistry &amp; guided implant placement reduce swelling and chair
                time.
              </p>
            </div>
          </motion.div>

          {/* Bottom-Right Floating Patient Reviews Pill */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.55, ease: CLINIC_EASE }}
            className="mt-3 md:mt-0 md:absolute md:right-6 md:bottom-6 inline-flex"
          >
            <a
              href="#testimonials"
              className="glass-surface-dark rounded-full pl-2.5 pr-5 py-2 inline-flex items-center gap-3 hover:scale-[1.02] transition-transform"
            >
              <span className="flex -space-x-2.5" aria-hidden="true">
                <img
                  src={CLINIC_IMAGES.cosmeticSmile}
                  alt=""
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover object-top ring-2 ring-white"
                />
                <img
                  src={CLINIC_IMAGES.ctaPatient}
                  alt=""
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover object-top ring-2 ring-white"
                />
                <img
                  src={CLINIC_IMAGES.consultation}
                  alt=""
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover object-top ring-2 ring-white"
                />
              </span>
              <span className="text-[13px] md:text-[14px] font-semibold text-[#14173A] tabular-nums">
                552+ happy reviews
              </span>
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
