import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { Award, Crosshair, HeartHandshake } from 'lucide-react';
import { CLINIC_IMAGES } from '../data/clinicData';
import { RevealBlock } from './MotionPrimitives';
import { PillTag } from './ClinicUI';

const PILLARS = [
  { icon: Award, label: 'Expert dental professionals' },
  { icon: Crosshair, label: 'Precision-driven treatments' },
  { icon: HeartHandshake, label: 'Patient-centric experience' },
];

export const IntroSection: React.FC = () => {
  const parallaxRef = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: parallaxRef,
    offset: ['start end', 'end start'],
  });

  // Left image shifts +40px, right image shifts -40px on scroll
  const leftY = useTransform(scrollYProgress, [0, 1], [-20, 20]);
  const rightY = useTransform(scrollYProgress, [0, 1], [20, -20]);

  return (
    <section id="about" className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <RevealBlock className="max-w-[820px] mx-auto text-center">
          <PillTag variant="teal" className="mb-6">
            From diagnosis to treatment
          </PillTag>

          <p className="text-[22px] sm:text-[26px] md:text-[28px] font-medium leading-[1.42] tracking-[-0.015em] text-[#14173A]">
            Every smile tells a story. Ours is built on trust, technology and transformation,
            whether you need a quick fix or a complete smile makeover.
          </p>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
            {PILLARS.map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="inline-flex items-center gap-2.5 text-[14px] md:text-[15px] font-medium text-[#0B4A5A]"
              >
                <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-white border border-[#14173A]/[0.06] text-[#3E8A9C] shadow-xs">
                  <Icon className="w-4 h-4" aria-hidden="true" />
                </span>
                <span>{label}</span>
              </div>
            ))}
          </div>
        </RevealBlock>

        {/* Asymmetric Dual Parallax Images */}
        <div
          ref={parallaxRef}
          className="mt-12 md:mt-16 grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10 items-start"
        >
          {/* Left lower image */}
          <motion.div
            style={{ y: leftY }}
            className="md:mt-12 overflow-hidden rounded-[20px] md:rounded-[24px] border border-[#14173A]/[0.06] bg-white shadow-[0_14px_34px_-14px_rgba(20,23,58,0.1)] group"
          >
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={CLINIC_IMAGES.clinicSuite}
                alt="Modern 4-chair dental clinic operatory with digital X-ray display at New Concepts Dental"
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]"
              />
            </div>
          </motion.div>

          {/* Right higher image */}
          <motion.div
            style={{ y: rightY }}
            className="overflow-hidden rounded-[20px] md:rounded-[24px] border border-[#14173A]/[0.06] bg-white shadow-[0_14px_34px_-14px_rgba(20,23,58,0.1)] group"
          >
            <div className="aspect-[4/3] overflow-hidden">
              <img
                src={CLINIC_IMAGES.consultation}
                alt="Dentist showing digital X-ray and dental treatment plan on tablet to smiling patient"
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
