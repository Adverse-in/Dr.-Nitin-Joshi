import React from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import { CLINIC_INFO } from '../data/clinicData';

export const MobileFloatingActions: React.FC = () => {
  return (
    <div
      className="md:hidden fixed bottom-4 right-4 z-30 flex items-center gap-2.5"
      aria-label="Quick clinic contact actions"
    >
      {/* [PLACEHOLDER: confirm official WhatsApp number] */}
      <a
        href={CLINIC_INFO.whatsappHref}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="w-12 h-12 rounded-full bg-white text-[#0B4A5A] border border-[#14173A]/10 shadow-lg flex items-center justify-center hover:bg-[#F7FAFC] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
      >
        <MessageCircle className="w-5 h-5" aria-hidden="true" />
      </a>
      <a
        href={CLINIC_INFO.phoneHref}
        aria-label="Call New Concepts Dental Clinic"
        className="h-12 px-4 rounded-full bg-[#0B4A5A] text-white shadow-lg flex items-center gap-2 text-[14px] font-medium hover:bg-[#093c49] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
      >
        <Phone className="w-4 h-4" aria-hidden="true" />
        <span>Call</span>
      </a>
    </div>
  );
};
