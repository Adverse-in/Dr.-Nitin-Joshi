import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Sparkles, Star } from 'lucide-react';
import { ROADMAP_STEPS } from '../data/clinicData';
import { CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { PillTag } from './ClinicUI';

const TRUST_SIGNALS = [
  { icon: Star, text: '4.9 on Google reviews' },
  { icon: Sparkles, text: 'Thousands of happy smiles' },
  { icon: ShieldCheck, text: 'Safe & certified care' },
];

export const RoadmapSection: React.FC = () => {
  return (
    <section className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <div className="rounded-[24px] md:rounded-[32px] bg-white border border-[#14173A]/[0.06] shadow-[0_18px_50px_-20px_rgba(20,23,58,0.08)] p-6 sm:p-10 md:p-14">
          {/* Header Row */}
          <RevealBlock className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-end pb-10 border-b border-[#14173A]/[0.06]">
            <div className="lg:col-span-7">
              <PillTag variant="teal" className="mb-4">
                Treatment roadmap
              </PillTag>
              <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-[#14173A]">
                Your journey to a healthier smile
              </h2>
            </div>
            <p className="lg:col-span-5 text-[16px] leading-[1.6] text-[#5B6475]">
              From your first phone call or clinicia.com booking to post-treatment follow-ups, we
              keep every step transparent, comfortable, and predictable.
            </p>
          </RevealBlock>

          {/* Steps with Animated SVG Dotted Connector */}
          <div className="relative pt-10 md:pt-12">
            {/* Desktop Dotted SVG Connector Line between 01 - 02 - 03 circles */}
            <svg
              viewBox="0 0 900 24"
              fill="none"
              className="hidden lg:block absolute top-[72px] left-[48px] right-[48px] w-[calc(100%-96px)] h-6 pointer-events-none"
              aria-hidden="true"
            >
              <motion.path
                d="M 10 12 L 890 12"
                stroke="#4FB3C8"
                strokeWidth="2"
                strokeDasharray="6 8"
                strokeLinecap="round"
                initial={{ pathLength: 0, opacity: 0.35 }}
                whileInView={{ pathLength: 1, opacity: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 1.2, ease: CLINIC_EASE }}
              />
            </svg>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative z-10">
              {ROADMAP_STEPS.map((step, idx) => (
                <motion.article
                  key={step.number}
                  initial={{ opacity: 0, y: 28 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{
                    duration: 0.65,
                    delay: idx * 0.15,
                    ease: CLINIC_EASE,
                  }}
                  className="rounded-[20px] md:rounded-[24px] bg-[#F7FAFC] border border-[#14173A]/[0.06] p-6 md:p-7 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_16px_32px_-14px_rgba(11,74,90,0.14)]"
                >
                  <div className="flex items-start justify-between gap-4">
                    <span className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#0B4A5A] text-white text-[15px] font-semibold tabular-nums ring-4 ring-white shadow-xs">
                      {step.number}
                    </span>
                    <div className="w-24 h-16 rounded-[14px] overflow-hidden border border-[#14173A]/[0.06] shrink-0">
                      <img
                        src={step.image}
                        alt={step.imageAlt}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  <div className="mt-8">
                    <h3 className="text-[21px] font-semibold text-[#14173A]">{step.title}</h3>
                    <p className="mt-2.5 text-[15px] leading-[1.6] text-[#5B6475]">
                      {step.description}
                    </p>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>

          {/* Bottom Trust Row */}
          <RevealBlock
            delay={0.2}
            className="mt-10 pt-8 border-t border-[#14173A]/[0.06] flex flex-wrap items-center justify-between gap-4"
          >
            {TRUST_SIGNALS.map(({ icon: Icon, text }) => (
              <div
                key={text}
                className="inline-flex items-center gap-2.5 text-[14px] md:text-[15px] font-medium text-[#14173A]"
              >
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#4FB3C8]/15 text-[#0B4A5A]">
                  <Icon className="w-4 h-4" aria-hidden="true" />
                </span>
                <span>{text}</span>
              </div>
            ))}
          </RevealBlock>
        </div>
      </div>
    </section>
  );
};
