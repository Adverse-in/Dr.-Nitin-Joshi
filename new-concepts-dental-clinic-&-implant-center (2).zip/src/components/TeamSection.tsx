import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';
import { CLINIC_IMAGES, CLINIC_INFO, TEAM_DOCTORS } from '../data/clinicData';
import { CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { CtaButton, PillTag } from './ClinicUI';

const KEY_AREAS = [
  'Gentle treatments',
  'Transparent advice',
  'Long-term results',
  'Additional care',
];

export const TeamSection: React.FC = () => {
  const bannerRef = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({
    target: bannerRef,
    offset: ['start end', 'end start'],
  });
  const bannerScale = useTransform(scrollYProgress, [0, 1], [1.06, 0.98]);

  return (
    <section id="team" className="pb-[72px] md:pb-[120px]">
      {/* Full-bleed Team Photo fading into #F7FAFC */}
      <div ref={bannerRef} className="relative overflow-hidden h-[280px] sm:h-[380px] md:h-[460px]">
        <motion.img
          style={{ scale: bannerScale }}
          src={CLINIC_IMAGES.teamBanner}
          alt="Dental doctors and friendly clinical support staff at New Concepts Dental Clinic in Dombivli"
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-top"
        />
        <div
          className="absolute inset-0 bg-gradient-to-b from-[#F7FAFC]/10 via-transparent to-[#F7FAFC]"
          aria-hidden="true"
        />
      </div>

      {/* Overlapping Content Container */}
      <div className="max-w-[1200px] mx-auto px-4 md:px-6 -mt-16 md:-mt-24 relative z-10">
        <RevealBlock className="max-w-[720px] mb-12 md:mb-14">
          <PillTag variant="light" className="mb-4 shadow-xs">
            Your trusted dental team
          </PillTag>
          <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-[#14173A]">
            People who care for your smile
          </h2>
          <p className="mt-4 text-[16px] leading-[1.6] text-[#5B6475]">
            Led by Dr. Nitin Joshi, our multi-specialist team brings together implantology,
            endodontics, cosmetic dentistry, and paediatric care under one calming roof.
          </p>
        </RevealBlock>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          {/* Left Sticky Info Column */}
          <RevealBlock className="lg:col-span-4 lg:sticky lg:top-24">
            <div className="rounded-[20px] md:rounded-[24px] bg-white border border-[#14173A]/[0.06] p-6 md:p-8 shadow-[0_10px_30px_-14px_rgba(20,23,58,0.08)] space-y-6">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#3E8A9C]">
                  Availability
                </p>
                <p className="mt-2 text-[17px] font-semibold text-[#14173A]">
                  {CLINIC_INFO.availabilityDays}
                </p>
                <p className="text-[15px] text-[#5B6475] mt-0.5">
                  Opens 10 AM · [PLACEHOLDER: closing time]
                </p>
              </div>

              <div className="pt-5 border-t border-[#14173A]/[0.06]">
                <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#3E8A9C] mb-3.5">
                  Key areas
                </p>
                <ul className="space-y-3">
                  {KEY_AREAS.map((area) => (
                    <li
                      key={area}
                      className="flex items-center gap-2.5 text-[15px] font-medium text-[#14173A]"
                    >
                      <CheckCircle2
                        className="w-4 h-4 text-[#4FB3C8] shrink-0"
                        aria-hidden="true"
                      />
                      <span>{area}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2">
                <CtaButton href="#contact" variant="primary" className="w-full">
                  Schedule a call
                </CtaButton>
              </div>
            </div>
          </RevealBlock>

          {/* Right 2x2 Grid of Doctor Portrait Cards */}
          {/* [PLACEHOLDER: Replace associate doctor names, qualifications, and photos with actual clinic team details] */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {TEAM_DOCTORS.map((doc, idx) => (
              <motion.article
                key={doc.name + idx}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.65,
                  delay: (idx % 2) * 0.12,
                  ease: CLINIC_EASE,
                }}
                className="relative overflow-hidden rounded-[20px] md:rounded-[24px] min-h-[430px] border border-[#14173A]/[0.06] bg-white group"
              >
                <img
                  src={doc.image}
                  alt={doc.imageAlt}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                />
                <div
                  className="absolute inset-0 bg-gradient-to-t from-[#0B4A5A]/55 via-transparent to-transparent"
                  aria-hidden="true"
                />

                <div className="relative z-10 h-full min-h-[430px] p-4 flex flex-col justify-end">
                  <div className="glass-surface-dark rounded-[18px] p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="text-[18px] font-semibold text-[#14173A]">{doc.name}</h3>
                    </div>
                    <span className="inline-block mt-1.5 text-[11px] font-semibold uppercase tracking-[0.06em] px-2.5 py-1 rounded-full bg-[#0B4A5A] text-white">
                      {doc.specialty}
                    </span>
                    <p className="mt-2.5 text-[13px] leading-[1.5] text-[#5B6475] line-clamp-2">
                      {doc.bio}
                    </p>
                    <p className="mt-2.5 pt-2.5 border-t border-[#14173A]/10 text-[12px] font-semibold text-[#0B4A5A]">
                      {doc.highlight}
                    </p>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
