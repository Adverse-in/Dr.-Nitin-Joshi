import React, { useCallback, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ChevronLeft, ChevronRight, MoveHorizontal, Quote } from 'lucide-react';
import { CLINIC_IMAGES, PATIENT_REVIEWS } from '../data/clinicData';
import { AnimatedCounter, CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { PillTag } from './ClinicUI';

export const TestimonialsSection: React.FC = () => {
  const [sliderPos, setSliderPos] = useState(52);
  const [dragging, setDragging] = useState(false);
  const sliderRef = useRef<HTMLDivElement | null>(null);

  const [reviewIdx, setReviewIdx] = useState(0);
  const activeReview = PATIENT_REVIEWS[reviewIdx];

  const updateSliderFromClientX = useCallback((clientX: number) => {
    const el = sliderRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setSliderPos(Math.max(4, Math.min(96, pct)));
  }, []);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    setDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    updateSliderFromClientX(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    updateSliderFromClientX(e.clientX);
  };

  const handlePointerUp = () => {
    setDragging(false);
  };

  const handleSliderKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setSliderPos((p) => Math.max(4, p - 4));
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      setSliderPos((p) => Math.min(96, p + 4));
    } else if (e.key === 'Home') {
      e.preventDefault();
      setSliderPos(4);
    } else if (e.key === 'End') {
      e.preventDefault();
      setSliderPos(96);
    }
  };

  const prevReview = () =>
    setReviewIdx((prev) => (prev - 1 + PATIENT_REVIEWS.length) % PATIENT_REVIEWS.length);
  const nextReview = () => setReviewIdx((prev) => (prev + 1) % PATIENT_REVIEWS.length);

  return (
    <section id="testimonials" className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <RevealBlock className="max-w-[680px] mb-10 md:mb-12">
          <PillTag variant="teal" className="mb-4">
            Patient experiences
          </PillTag>
          <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-[#14173A]">
            Treatment outcomes you can trust
          </h2>
        </RevealBlock>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left: Interactive Before/After Slider */}
          <RevealBlock className="lg:col-span-6">
            <div className="relative h-full min-h-[340px] sm:min-h-[420px] rounded-[20px] md:rounded-[24px] overflow-hidden border border-[#14173A]/[0.06] bg-white shadow-[0_14px_34px_-14px_rgba(20,23,58,0.1)] select-none">
              <div
                ref={sliderRef}
                role="slider"
                tabIndex={0}
                aria-label="Before and after cosmetic dental treatment comparison"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Math.round(sliderPos)}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
                onKeyDown={handleSliderKeyDown}
                className="relative w-full h-full min-h-[340px] sm:min-h-[420px] cursor-ew-resize touch-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
              >
                {/* After Image (Full Base) */}
                {/* [REPLACE WITH CLINIC PHOTO] Real clinical after-treatment smile photo */}
                <img
                  src={CLINIC_IMAGES.afterSmile}
                  alt="Teeth after professional whitening and porcelain veneers treatment"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                />

                {/* Before Image (Clipped Left Portion) */}
                {/* [REPLACE WITH CLINIC PHOTO] Real clinical before-treatment smile photo */}
                <div
                  className="absolute inset-0 overflow-hidden pointer-events-none"
                  style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
                >
                  <img
                    src={CLINIC_IMAGES.beforeSmile}
                    alt="Teeth before cosmetic whitening and alignment care"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Before / After Corner Labels */}
                <span className="pointer-events-none absolute top-4 left-4 rounded-full bg-[#14173A]/75 backdrop-blur-sm text-white text-[11px] font-semibold uppercase tracking-[0.08em] px-3 py-1">
                  Before
                </span>
                <span className="pointer-events-none absolute top-4 right-4 rounded-full bg-[#0B4A5A]/85 backdrop-blur-sm text-white text-[11px] font-semibold uppercase tracking-[0.08em] px-3 py-1">
                  After
                </span>

                {/* Vertical Divider & Circular Handle */}
                <div
                  className="pointer-events-none absolute top-0 bottom-0 w-[2px] bg-white shadow-[0_0_12px_rgba(0,0,0,0.25)]"
                  style={{ left: `${sliderPos}%` }}
                >
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white text-[#0B4A5A] shadow-lg border border-[#14173A]/10 flex items-center justify-center">
                    <MoveHorizontal className="w-5 h-5" aria-hidden="true" />
                  </div>
                </div>
              </div>
            </div>
          </RevealBlock>

          {/* Right: Teal Gradient Quote Card */}
          <RevealBlock delay={0.12} className="lg:col-span-6">
            <div className="relative h-full min-h-[380px] sm:min-h-[420px] rounded-[20px] md:rounded-[24px] bg-gradient-to-br from-[#0B4A5A] via-[#0B4A5A] to-[#3E8A9C] text-white p-7 sm:p-10 pb-20 flex flex-col justify-between overflow-hidden shadow-[0_20px_48px_-18px_rgba(11,74,90,0.4)]">
              {/* Large Faded Quote Mark */}
              <Quote
                className="w-16 h-16 text-white/10 absolute top-6 right-7 pointer-events-none"
                aria-hidden="true"
              />

              <div className="relative z-10 flex-1 flex flex-col justify-center">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={reviewIdx}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.35, ease: CLINIC_EASE }}
                    className="space-y-7"
                  >
                    <blockquote className="text-[22px] sm:text-[26px] font-medium leading-[1.38] tracking-[-0.01em] text-white">
                      “{activeReview.quote}”
                    </blockquote>

                    <div className="flex items-center gap-3.5">
                      <img
                        src={activeReview.avatar}
                        alt={activeReview.author}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-full object-cover object-top ring-2 ring-white/30"
                      />
                      <div>
                        <p className="text-[15px] font-semibold text-white">
                          {activeReview.author}
                        </p>
                        <p className="text-[13px] text-[#4FB3C8]">{activeReview.context}</p>
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Floating White Bottom Navigation Tab */}
              <div className="absolute bottom-5 right-6 inline-flex items-center gap-2 rounded-full bg-white text-[#14173A] p-1.5 shadow-md">
                <button
                  type="button"
                  onClick={prevReview}
                  aria-label="Previous patient review"
                  className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-[#F7FAFC] text-[#0B4A5A] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
                >
                  <ChevronLeft className="w-4 h-4" aria-hidden="true" />
                </button>
                <span className="text-[12px] font-semibold tabular-nums px-1.5 text-[#5B6475]">
                  {reviewIdx + 1} / {PATIENT_REVIEWS.length}
                </span>
                <button
                  type="button"
                  onClick={nextReview}
                  aria-label="Next patient review"
                  className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-[#F7FAFC] text-[#0B4A5A] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8]"
                >
                  <ChevronRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </RevealBlock>
        </div>

        {/* Animated Stats Row */}
        <RevealBlock className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          <div className="clinic-card rounded-[20px] p-6">
            <p className="text-[34px] md:text-[40px] font-semibold text-[#0B4A5A] leading-none">
              <AnimatedCounter target={4.9} decimals={1} />
            </p>
            <p className="mt-2 text-[14px] font-medium text-[#5B6475]">Google rating</p>
          </div>
          <div className="clinic-card rounded-[20px] p-6">
            <p className="text-[34px] md:text-[40px] font-semibold text-[#0B4A5A] leading-none">
              <AnimatedCounter target={552} suffix="+" />
            </p>
            <p className="mt-2 text-[14px] font-medium text-[#5B6475]">Verified reviews</p>
          </div>
          <div className="clinic-card rounded-[20px] p-6">
            <p className="text-[34px] md:text-[40px] font-semibold text-[#0B4A5A] leading-none">
              <AnimatedCounter target={40} />
            </p>
            <p className="mt-2 text-[14px] font-medium text-[#5B6475]">Years of trust</p>
          </div>
          <div className="clinic-card rounded-[20px] p-6">
            <p className="text-[34px] md:text-[40px] font-semibold text-[#0B4A5A] leading-none">
              <AnimatedCounter target={4} />
            </p>
            <p className="mt-2 text-[14px] font-medium text-[#5B6475]">Modern chairs</p>
          </div>
        </RevealBlock>
      </div>
    </section>
  );
};
