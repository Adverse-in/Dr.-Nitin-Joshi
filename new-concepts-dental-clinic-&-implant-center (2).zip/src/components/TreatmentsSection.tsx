import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Heart, Layers, ShieldCheck, Smile, Sparkles, Zap } from 'lucide-react';
import { ALL_SERVICES, CLINIC_INFO, TREATMENT_TABS, TreatmentTab } from '../data/clinicData';
import { CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { CtaButton, PillTag } from './ClinicUI';

const ICON_MAP = {
  sparkles: Sparkles,
  shield: ShieldCheck,
  smile: Smile,
  heart: Heart,
  layers: Layers,
  zap: Zap,
};

export const TreatmentsSection: React.FC = () => {
  const [activeId, setActiveId] = useState<TreatmentTab['id']>('cosmetic');
  const activeTab = TREATMENT_TABS.find((t) => t.id === activeId) ?? TREATMENT_TABS[0];

  const handleKeyDown = (e: React.KeyboardEvent, idx: number) => {
    if (e.key === 'ArrowRight') {
      const next = TREATMENT_TABS[(idx + 1) % TREATMENT_TABS.length];
      setActiveId(next.id);
    } else if (e.key === 'ArrowLeft') {
      const prev = TREATMENT_TABS[(idx - 1 + TREATMENT_TABS.length) % TREATMENT_TABS.length];
      setActiveId(prev.id);
    }
  };

  return (
    <section id="treatments" className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <RevealBlock className="text-center max-w-[720px] mx-auto">
          <PillTag variant="teal" className="mb-5">
            Comprehensive care
          </PillTag>
          <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-[#14173A]">
            Precision dentistry backed by innovation
          </h2>
          <p className="mt-4 text-[16px] leading-[1.6] text-[#5B6475]">
            Explore our core clinical departments across 4 fully equipped chairs—from laser
            dentistry and painless implants to gentle paediatric care.
          </p>
        </RevealBlock>

        {/* Horizontally Scrollable Tabs with Animated Underline */}
        <div className="mt-10 border-b border-[#14173A]/[0.08]">
          <div
            role="tablist"
            aria-label="Dental treatment categories"
            className="flex items-center md:justify-center gap-6 md:gap-10 overflow-x-auto no-scrollbar px-1"
          >
            {TREATMENT_TABS.map((tab, idx) => {
              const isActive = tab.id === activeId;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  type="button"
                  id={`tab-${tab.id}`}
                  aria-selected={isActive}
                  aria-controls={`panel-${tab.id}`}
                  tabIndex={isActive ? 0 : -1}
                  onClick={() => setActiveId(tab.id)}
                  onKeyDown={(e) => handleKeyDown(e, idx)}
                  className={`relative pb-4 text-[15px] md:text-[16px] font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4FB3C8] rounded-sm ${
                    isActive ? 'text-[#0B4A5A]' : 'text-[#5B6475] hover:text-[#14173A]'
                  }`}
                >
                  {tab.label}
                  {isActive && (
                    <motion.span
                      layoutId="treatmentTabUnderline"
                      transition={{ duration: 0.3, ease: CLINIC_EASE }}
                      className="absolute left-0 right-0 bottom-0 h-[2.5px] bg-[#4FB3C8] rounded-full"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab.id}
            role="tabpanel"
            id={`panel-${activeTab.id}`}
            aria-labelledby={`tab-${activeTab.id}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.35, ease: CLINIC_EASE }}
            className="mt-10 space-y-8"
          >
            {/* 3 Feature Columns */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6">
              {activeTab.features.map((feat) => {
                const Icon = ICON_MAP[feat.iconName];
                return (
                  <div
                    key={feat.title}
                    className="clinic-card rounded-[20px] md:rounded-[24px] p-6 md:p-7"
                  >
                    <span className="inline-flex items-center justify-center w-11 h-11 rounded-full bg-[#4FB3C8]/15 text-[#0B4A5A]">
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </span>
                    <h3 className="mt-4 text-[18px] font-semibold text-[#14173A]">
                      {feat.title}
                    </h3>
                    <p className="mt-2 text-[15px] leading-[1.6] text-[#5B6475]">
                      {feat.detail}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* Large Rounded Treatment Photo */}
            <motion.div
              initial={{ opacity: 0.7, scale: 0.985 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.45, ease: CLINIC_EASE }}
              className="overflow-hidden rounded-[20px] md:rounded-[24px] border border-[#14173A]/[0.06] bg-white aspect-[16/9] max-h-[460px] w-full group"
            >
              <img
                src={activeTab.image}
                alt={activeTab.imageAlt}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.04]"
              />
            </motion.div>

            {/* Bottom Summary Row */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center pt-2">
              <div className="lg:col-span-6">
                <h3 className="text-[24px] md:text-[28px] font-semibold leading-[1.25] tracking-[-0.02em] text-[#14173A]">
                  {activeTab.headline}
                </h3>
              </div>
              <div className="lg:col-span-6 space-y-5">
                <p className="text-[16px] leading-[1.6] text-[#5B6475]">
                  {activeTab.description}
                </p>
                <CtaButton href={CLINIC_INFO.bookingUrl} external variant="primary">
                  {activeTab.ctaLabel}
                </CtaButton>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Complete 16-Service Directory Line */}
        <RevealBlock className="mt-12 pt-8 border-t border-[#14173A]/[0.08]">
          <p className="text-[12px] font-semibold uppercase tracking-[0.08em] text-[#3E8A9C] mb-3">
            Complete services available in-clinic
          </p>
          <p className="text-[14px] md:text-[15px] leading-[1.8] text-[#5B6475]">
            {ALL_SERVICES.join(' · ')}
          </p>
        </RevealBlock>
      </div>
    </section>
  );
};
