import React from 'react';
import { motion } from 'motion/react';
import { Clock, IndianRupee, Smile, AlertCircle } from 'lucide-react';
import { AVOIDANCE_STATS, CLINIC_IMAGES } from '../data/clinicData';
import { CLINIC_EASE, RevealBlock } from './MotionPrimitives';
import { PillTag } from './ClinicUI';

const STAT_ICONS = [Clock, IndianRupee, Smile, AlertCircle];

export const WhyAvoidSection: React.FC = () => {
  return (
    <section className="pb-[72px] md:pb-[120px]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          {/* Left Sticky Tall Image Card */}
          <RevealBlock className="lg:col-span-5 lg:sticky lg:top-24">
            <div className="relative overflow-hidden rounded-[20px] md:rounded-[24px] min-h-[420px] lg:min-h-[540px] border border-[#14173A]/[0.06] group">
              <img
                src={CLINIC_IMAGES.worriedPatient}
                alt="Patient holding cheek feeling anxious about delaying a dental checkup"
                loading="lazy"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]"
              />
              {/* Measured Contrast Scrim */}
              <div
                className="absolute inset-0 bg-gradient-to-t from-[#0B4A5A]/95 via-[#0B4A5A]/55 to-[#14173A]/35"
                aria-hidden="true"
              />

              <div className="relative z-10 h-full min-h-[420px] lg:min-h-[540px] p-6 md:p-8 flex flex-col justify-between text-white">
                <div>
                  <PillTag variant="dark" className="mb-5">
                    Stats and facts
                  </PillTag>
                  <h2 className="text-[32px] md:text-[40px] font-semibold leading-[1.15] tracking-[-0.02em] text-white">
                    Why people avoid dental treatments?
                  </h2>
                </div>

                <p className="text-[15px] leading-[1.6] text-white/90 pt-6 border-t border-white/20">
                  We solve the reasons people hesitate, with painless, fast and transparent care.
                </p>
              </div>
            </div>
          </RevealBlock>

          {/* Right 2x2 Grid of Soft Stat Cards */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5 md:gap-6">
            {AVOIDANCE_STATS.map((item, idx) => {
              const Icon = STAT_ICONS[idx % STAT_ICONS.length];
              return (
                <motion.article
                  key={item.label}
                  initial={{ opacity: 0, x: 28 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{
                    duration: 0.65,
                    delay: idx * 0.15,
                    ease: CLINIC_EASE,
                  }}
                  className="clinic-card rounded-[20px] md:rounded-[24px] p-6 md:p-8 flex flex-col justify-between min-h-[240px] md:min-h-[258px]"
                >
                  <div className="flex items-start justify-between gap-4">
                    <span className="text-[40px] md:text-[48px] font-semibold leading-none tracking-[-0.02em] text-[#0B4A5A] tabular-nums">
                      {item.stat}
                    </span>
                    <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#F7FAFC] border border-[#14173A]/[0.06] text-[#3E8A9C]">
                      <Icon className="w-4 h-4" aria-hidden="true" />
                    </span>
                  </div>

                  <div className="mt-8">
                    <h3 className="text-[20px] font-semibold text-[#14173A]">{item.label}</h3>
                    <p className="mt-2 text-[15px] leading-[1.6] text-[#5B6475]">
                      {item.description}
                    </p>
                    <p className="mt-3 text-[11px] font-medium text-[#3E8A9C]">
                      {item.placeholderNote}
                    </p>
                  </div>
                </motion.article>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
