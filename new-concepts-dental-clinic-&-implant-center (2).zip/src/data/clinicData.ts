// [REPLACE WITH CLINIC PHOTO] Swap any generated asset import below with actual photography from Nitin Joshi's New Concepts Dental Clinic.
import heroDentalTreatment from '../assets/images/hero_dental_treatment_1794599382918.jpg';
import clinicModernSuite from '../assets/images/clinic_modern_suite_1794599383517.jpg';
import dentistPatientConsult from '../assets/images/dentist_patient_consult_1794599382863.jpg';
import worriedPatientCheek from '../assets/images/worried_patient_cheek_1794599383992.jpg';
import cosmeticSmileCare from '../assets/images/cosmetic_smile_care_1794599384484.jpg';
import dentalImplantPrecision from '../assets/images/dental_implant_precision_1794599385876.jpg';
import preventiveDentalCheckup from '../assets/images/preventive_dental_checkup_1794599385101.jpg';
import restorativeDentalCare from '../assets/images/restorative_dental_care_1794599385955.jpg';
import drNitinJoshi from '../assets/images/dr_nitin_joshi_1794599387369.jpg';
import dentalTeamBanner from '../assets/images/dental_team_banner_1794599387354.jpg';
import doctorPortraitFemale from '../assets/images/doctor_portrait_female_1794599387237.jpg';
import doctorPortraitMaleYoung from '../assets/images/doctor_portrait_male_young_1794599387174.jpg';
import doctorPortraitSeniorFemale from '../assets/images/doctor_portrait_senior_female_1794599387723.jpg';
import beforeTeethSmile from '../assets/images/before_teeth_smile_1794599387812.jpg';
import afterTeethSmile from '../assets/images/after_teeth_smile_1794599388376.jpg';
import ctaHappyPatient from '../assets/images/cta_happy_patient_1794599389199.jpg';
import footerTooth3d from '../assets/images/footer_tooth_3d_1794599388896.jpg';

export const CLINIC_IMAGES = {
  // [REPLACE WITH CLINIC PHOTO] Hero main clinic treatment room photo
  heroTreatment: heroDentalTreatment,
  // [REPLACE WITH CLINIC PHOTO] 4-chair clinic suite interior
  clinicSuite: clinicModernSuite,
  // [REPLACE WITH CLINIC PHOTO] Doctor-patient digital consultation photo
  consultation: dentistPatientConsult,
  // [REPLACE WITH CLINIC PHOTO] Worried patient holding cheek
  worriedPatient: worriedPatientCheek,
  // [REPLACE WITH CLINIC PHOTO] Treatment category photos
  cosmeticSmile: cosmeticSmileCare,
  preventiveCheckup: preventiveDentalCheckup,
  restorativeCare: restorativeDentalCare,
  implantPrecision: dentalImplantPrecision,
  // [REPLACE WITH CLINIC PHOTO] Lead & associate doctor portraits
  drNitinJoshi,
  teamBanner: dentalTeamBanner,
  doctorFemale: doctorPortraitFemale,
  doctorMaleYoung: doctorPortraitMaleYoung,
  doctorSeniorFemale: doctorPortraitSeniorFemale,
  // [REPLACE WITH CLINIC PHOTO] Real patient smile transformation photos
  beforeSmile: beforeTeethSmile,
  afterSmile: afterTeethSmile,
  // [REPLACE WITH CLINIC PHOTO] Happy patient CTA banner
  ctaPatient: ctaHappyPatient,
  // [REPLACE WITH CLINIC PHOTO] Footer 3D tooth visual
  footerTooth: footerTooth3d,
} as const;

export const CLINIC_INFO = {
  brandShort: 'New Concepts Dental',
  fullName: "Nitin Joshi's New Concepts Dental Clinic and Implant Center",
  tagline: 'Dental implants, EMI available. Safe and painless treatment.',
  rating: '4.9',
  reviewCount: '552',
  yearsLegacy: '40',
  chairsCount: '4',
  address:
    '1st Floor, Gauri Shankar Apartment, 8, near Bharat Natya Mandir, Shastri Nagar, Dombivli West, Maharashtra 421202',
  phoneDisplay: '099676 68923',
  phoneHref: 'tel:+919967668923',
  // [PLACEHOLDER: confirm official clinic WhatsApp number]
  whatsappHref: 'https://wa.me/919967668923',
  // [PLACEHOLDER: confirm exact Clinicia clinic booking URL]
  bookingUrl: 'https://clinicia.com',
  // [PLACEHOLDER: add official clinic email address]
  emailDisplay: '[PLACEHOLDER: contact@newconceptsdental.in]',
  hours: 'Opens 10 AM · [PLACEHOLDER: closing time and open days]',
  availabilityDays: '[PLACEHOLDER: Mon – Sat]',
  googleMapsEmbedUrl:
    'https://www.google.com/maps?q=Gauri+Shankar+Apartment,+Shastri+Nagar,+Dombivli+West,+Maharashtra+421202&output=embed',
};

export const ALL_SERVICES = [
  'Teeth whitening',
  'Check-ups',
  'Cosmetic procedures',
  'Dental implants',
  'Dentures & bridges',
  'Emergency care',
  'Extractions',
  'Fillings & sealants',
  'Laser dentistry',
  'Oral surgery',
  'Paediatrics',
  'Root canals',
  'Teeth cleaning',
  'Teeth reshaping',
  'Veneers & crowns',
  'X-ray',
] as const;

export interface TreatmentTab {
  id: 'cosmetic' | 'preventive' | 'restorative' | 'implants';
  label: string;
  image: string;
  imageAlt: string;
  headline: string;
  description: string;
  ctaLabel: string;
  features: {
    title: string;
    detail: string;
    iconName: 'sparkles' | 'shield' | 'smile' | 'heart' | 'layers' | 'zap';
  }[];
}

export const TREATMENT_TABS: TreatmentTab[] = [
  {
    id: 'cosmetic',
    label: 'Cosmetic',
    image: CLINIC_IMAGES.cosmeticSmile,
    imageAlt: 'Confident smiling patient after cosmetic teeth whitening and veneers in Dombivli',
    headline: 'Natural-looking aesthetic dentistry tailored to your face.',
    description:
      'From gentle chairside teeth whitening to custom veneers, crowns, and enamel reshaping, every cosmetic procedure is planned around healthy tooth preservation.',
    ctaLabel: 'Book cosmetic consult',
    features: [
      {
        title: 'Teeth whitening',
        detail: 'Safe, enamel-friendly brightening that lifts deep stains without post-visit sensitivity.',
        iconName: 'sparkles',
      },
      {
        title: 'Veneers & crowns',
        detail: 'Precision-crafted porcelain veneers and metal-free crowns matched to your natural shade.',
        iconName: 'layers',
      },
      {
        title: 'Teeth reshaping',
        detail: 'Subtle cosmetic procedures and contouring to smooth chipped edges and balance symmetry.',
        iconName: 'smile',
      },
    ],
  },
  {
    id: 'preventive',
    label: 'Preventive',
    image: CLINIC_IMAGES.preventiveCheckup,
    imageAlt: 'Gentle routine dental check-up in a bright modern clinic room',
    headline: 'Early digital X-rays and calm family check-ups.',
    description:
      'Routine check-ups, ultrasonic teeth cleaning, paediatric visits, and protective fillings help Dombivli families stop minor decay before it becomes painful.',
    ctaLabel: 'Schedule a check-up',
    features: [
      {
        title: 'Check-ups & X-ray',
        detail: 'Thorough oral exams paired with low-radiation digital X-rays for clear, fast diagnosis.',
        iconName: 'shield',
      },
      {
        title: 'Teeth cleaning',
        detail: 'Gentle scaling and polishing to remove plaque, tartar, and surface staining comfortably.',
        iconName: 'sparkles',
      },
      {
        title: 'Fillings & sealants',
        detail: 'Tooth-coloured composite fillings and paediatric sealants that protect growing smiles.',
        iconName: 'heart',
      },
    ],
  },
  {
    id: 'restorative',
    label: 'Restorative',
    image: CLINIC_IMAGES.restorativeCare,
    imageAlt: 'Precision porcelain dental crown model and clean restorative instruments',
    headline: 'Pain-relieving root canals, bridges, and emergency care.',
    description:
      'Whether you need single-sitting root canal relief, natural dentures & bridges, or calm urgent extractions, our 4-chair clinic keeps visits swift and reassuring.',
    ctaLabel: 'Book pain relief',
    features: [
      {
        title: 'Root canals',
        detail: 'Rotary endodontic therapy under effective anaesthesia for calm, comfortable tooth saving.',
        iconName: 'shield',
      },
      {
        title: 'Dentures & bridges',
        detail: 'Well-fitted fixed bridges and custom dentures designed for natural chewing and speech.',
        iconName: 'layers',
      },
      {
        title: 'Extractions & urgent care',
        detail: 'Atraumatic extractions and same-day emergency care when sudden toothache strikes.',
        iconName: 'heart',
      },
    ],
  },
  {
    id: 'implants',
    label: 'Implants & Surgery',
    image: CLINIC_IMAGES.implantPrecision,
    imageAlt: 'Digital 3D dental implant planning monitor and precision implant model',
    headline: 'Painless dental implants with flexible EMI options.',
    description:
      'Guided implant placement, minimally invasive laser dentistry, and safe oral surgery backed by 40 years of clinical judgement and transparent EMI plans.',
    ctaLabel: 'Explore implant EMI',
    features: [
      {
        title: 'Dental implants (EMI available)',
        detail: 'Long-lasting titanium tooth roots with convenient monthly EMI options for peace of mind.',
        iconName: 'layers',
      },
      {
        title: 'Oral surgery',
        detail: 'Impacted wisdom tooth removal and minor surgical procedures with sterile protocols.',
        iconName: 'shield',
      },
      {
        title: 'Laser dentistry',
        detail: 'Soft-tissue laser treatments that reduce bleeding, discomfort, and healing time.',
        iconName: 'zap',
      },
    ],
  },
];

export const AVOIDANCE_STATS = [
  {
    stat: '64%',
    label: 'Delay visits',
    description: 'Postpone check-ups out of anxiety over pain or lengthy waiting room queues.',
    placeholderNote: '[PLACEHOLDER: verify stats]',
  },
  {
    stat: '₹',
    label: 'Cost fear',
    description: 'Hesitate to start dental implants or crowns without clear upfront pricing & EMI.',
    placeholderNote: '[PLACEHOLDER: verify stats]',
  },
  {
    stat: '3 in 5',
    label: 'Hide their smile',
    description: 'Feel self-conscious in photos or conversations due to discoloured or missing teeth.',
    placeholderNote: '[PLACEHOLDER: verify stats]',
  },
  {
    stat: '90%',
    label: 'Regret waiting',
    description: 'Wish they had treated minor sensitivity earlier before needing extensive care.',
    placeholderNote: '[PLACEHOLDER: verify stats]',
  },
];

export const ROADMAP_STEPS = [
  {
    number: '01',
    title: 'Schedule with ease',
    description:
      'Book your slot in under a minute via phone on 099676 68923 or online through clinicia.com across our 4 modern dental chairs.',
    image: CLINIC_IMAGES.clinicSuite,
    imageAlt: 'Four-chair dental clinic suite ready for patient scheduling',
  },
  {
    number: '02',
    title: 'Personalized care',
    description:
      'We explain every digital X-ray and treatment option step-by-step, delivering safe, gentle care with zero pressure.',
    image: CLINIC_IMAGES.consultation,
    imageAlt: 'Dentist explaining personalized treatment plan on a tablet',
  },
  {
    number: '03',
    title: 'Ongoing support',
    description:
      'Leave with clear recovery guidance, easy EMI schedules where needed, and friendly follow-up reminders for lasting oral health.',
    image: CLINIC_IMAGES.cosmeticSmile,
    imageAlt: 'Happy patient enjoying long-term healthy smile results',
  },
];

export interface TeamDoctor {
  name: string;
  specialty: string;
  bio: string;
  highlight: string;
  image: string;
  imageAlt: string;
}

export const TEAM_DOCTORS: TeamDoctor[] = [
  {
    name: 'Dr. Nitin Joshi',
    specialty: 'Implant & Cosmetic Dentist',
    bio: '[PLACEHOLDER: MDS/BDS qualification & years of experience] leading our family practice in Dombivli West with calm precision.',
    highlight: '40 years of trusted family dental care',
    image: CLINIC_IMAGES.drNitinJoshi,
    imageAlt: 'Dr. Nitin Joshi, Implant and Cosmetic Dentist in Dombivli West',
  },
  {
    name: '[PLACEHOLDER: Dr. Name 2]',
    specialty: '[PLACEHOLDER: Endodontist & Restorative]',
    bio: '[PLACEHOLDER: qualification, years of experience] specializing in painless root canals, laser dentistry, and conservative restorations.',
    highlight: 'Gentle, single-sitting care focus',
    image: CLINIC_IMAGES.doctorFemale,
    imageAlt: 'Associate restorative and laser dentist at New Concepts Dental Clinic',
  },
  {
    name: '[PLACEHOLDER: Dr. Name 3]',
    specialty: '[PLACEHOLDER: Oral Surgeon & Prosthodontics]',
    bio: '[PLACEHOLDER: qualification, years of experience] focused on atraumatic extractions, crowns, bridges, and implant prosthetics.',
    highlight: 'Precision implant & crown fitting',
    image: CLINIC_IMAGES.doctorMaleYoung,
    imageAlt: 'Specialist oral surgeon and prosthodontist at New Concepts Dental Clinic',
  },
  {
    name: '[PLACEHOLDER: Dr. Name 4]',
    specialty: '[PLACEHOLDER: Paediatric & Preventive Care]',
    bio: '[PLACEHOLDER: qualification, years of experience] helping children and anxious patients feel relaxed through calm, friendly visits.',
    highlight: 'Kid-friendly, fear-free dentistry',
    image: CLINIC_IMAGES.doctorSeniorFemale,
    imageAlt: 'Paediatric and family dentist at New Concepts Dental Clinic',
  },
];

export interface PatientReview {
  quote: string;
  author: string;
  context: string;
  avatar: string;
}

export const PATIENT_REVIEWS: PatientReview[] = [
  {
    quote: 'Care and treatment with a homely atmosphere at New Concept.',
    author: '[PLACEHOLDER: Google Reviewer Name]',
    context: 'Verified Google Review · 4.9★ Rating',
    avatar: CLINIC_IMAGES.ctaPatient,
  },
  {
    quote: 'Both the doctors and staff were excellent at their work and treated me kindly.',
    author: '[PLACEHOLDER: Google Reviewer Name]',
    context: 'Verified Google Review · Family Care',
    avatar: CLINIC_IMAGES.cosmeticSmile,
  },
  {
    quote:
      '[PLACEHOLDER: Add 3rd verified Google review quote about painless dental implants or root canal treatment.]',
    author: '[PLACEHOLDER: Google Reviewer Name]',
    context: 'Verified Google Review · Dental Implants',
    avatar: CLINIC_IMAGES.consultation,
  },
];

export const FAQ_ITEMS = [
  {
    question: 'What dental services do you offer?',
    answer:
      'We provide complete family and specialist care under one roof: Teeth whitening, Check-ups, Cosmetic procedures, Dental implants, Dentures & bridges, Emergency care, Extractions, Fillings & sealants, Laser dentistry, Oral surgery, Paediatrics, Root canals, Teeth cleaning, Teeth reshaping, Veneers & crowns, and digital X-rays.',
  },
  {
    question: 'How do I book an appointment?',
    answer:
      'You can book online directly through our clinicia.com appointment link, call us on 099676 68923 from 10 AM onwards, or submit your preferred date using the contact form below.',
  },
  {
    question: 'Are implants painful and is EMI available?',
    answer:
      'Dental implants are placed gently under effective local anaesthesia using modern digital planning and laser support for comfortable recovery. Yes, flexible EMI options are available so you can plan your treatment stress-free.',
  },
  {
    question: 'Is teeth whitening safe?',
    answer:
      'Yes. In-clinic teeth whitening performed after a dental check-up uses clinically tested, enamel-safe formulas that brighten your natural smile without damaging tooth structure.',
  },
  {
    question: 'How often should I get a check-up?',
    answer:
      'We recommend a routine check-up and professional teeth cleaning every 6 months. Regular visits let us catch early cavities or gum inflammation before they require complex procedures.',
  },
  {
    question: 'Do you treat children?',
    answer:
      'Yes! Paediatric dentistry is a core part of our 40-year family practice in Dombivli. We offer gentle check-ups, preventive sealants, cavity fillings, and calm guidance tailored for children.',
  },
  {
    question: 'What makes your clinic different?',
    answer:
      'New Concepts Dental combines 40 years of multi-generational family trust in Dombivli West with a spacious 4-chair modern clinic, digital X-rays, laser dentistry, a 4.9 Google rating across 552+ reviews, and honest, transparent advice.',
  },
];
